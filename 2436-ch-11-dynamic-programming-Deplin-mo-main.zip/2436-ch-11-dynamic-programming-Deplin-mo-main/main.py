def knapsack(items, capacity):
    n = len(items)
    
    # grid[i][w] = list of items chosen
    grid = [[[] for _ in range(capacity + 1)] for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        item_name, weight, value = items[i - 1]
        
        for w in range(1, capacity + 1):
            if weight > w:
                grid[i][w] = grid[i - 1][w][:]
            else:
                include_items = grid[i - 1][w - weight][:] + [(item_name, weight, value)]
                include_value = sum(v for _, _, v in include_items)
                
                exclude_items = grid[i - 1][w][:]
                exclude_value = sum(v for _, _, v in exclude_items)
                
                if include_value >= exclude_value:
                    grid[i][w] = include_items
                else:
                    grid[i][w] = exclude_items
    
    return grid


def display_grid(grid, items):
    n = len(items)
    cell_width = 12  
    
    # Header row
    header = ""
    for i in range(1, len(grid[0])):
        header += f"{i:<{cell_width}}"
    print(" " * cell_width + header)
    
    # Rows
    for i in range(1, n + 1):
        item_name = items[i - 1][0]
        row = f"{item_name:<16}"
        
        for cell in grid[i][1:]:
            if cell:
                total_value = sum(v for _, _, v in cell)
                item_letters = "".join(name[0] for name, _, _ in cell)
                cell_str = f"${total_value}({item_letters})"
                row += f"{cell_str:<{cell_width}}"
            else:
                row += " " * cell_width
        
        print(row)


# Test data
items = [
    ("GUITAR", 1, 1500),
    ("STEREO", 4, 3000),
    ("LAPTOP", 3, 2000),
    ("iPHONE", 1, 2000),
    ("BOOK", 2, 100),
    ("GOLD BAR", 1, 30000)
]

capacity = 6

# Run knapsack
grid = knapsack(items, capacity)

# Display result
display_grid(grid, items)