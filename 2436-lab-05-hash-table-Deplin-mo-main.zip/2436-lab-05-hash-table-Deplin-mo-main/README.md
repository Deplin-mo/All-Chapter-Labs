[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=22848092&assignment_repo_type=AssignmentRepo)
# Lab 05: 2436 Hash Table Lab 05

## Student Information
- **Name:** [Devon Hajdik]
- **Date:** [5/7/2026]

## Key Concepts
Hash Tables store information in a key-value pair style, meaning each key in a list is tied to a value. A collision can occur if two or more 
keys map to the same index. 

## What I Learned
Hash Tables are very helpful creating things like product lists and dictionaries and phonebooks.

## Challenges
Having to remember the load factor based on the size of the list. 

## Reflection Questions
1. Hash Tables allow you to quickly search up an item based on a key without having to go through the entire list to find something.
2. Ideally, the hash function assigns a unique key to each value in order to avoid collisions and tries to maintain a O(1) time progression.
3. Because each index holds a linked list, of entries, multiple items of the same key can be merged into one, but it does increase memory usage.

---
*Complete this lab report after finishing the coding portion. Your final commit should include both working code and a completed lab report.*
