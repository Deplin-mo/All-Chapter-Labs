[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=23368017&assignment_repo_type=AssignmentRepo)
# 2436 Lab 8 Balanced Trees

## Setup

```bash
# Clone this repository
git clone <your-repo-url>
cd <repo-name>
```

## Running the Code

```bash
python3 solution.py
```


## Testing

Tests are automatically run via GitHub Actions on every push.

To run tests locally:
```bash
# See .github/workflows/classroom.yml for test commands
```
## Autograding

This assignment uses GitHub Classroom autograding. Your score is calculated based on:
- Code compilation (if applicable)
- Test results
- Code quality

See `.github/classroom/autograding.json` for the full grading rubric.


## Lab Report

### Student Information
- **Name:** [Devon Hajdik]
- **Date:** [5/7/2026]

### Algorithm Analysis

#### AVL Trees
- **Balance Factor Range:** The tree is considered balanced if the difference in height between the left and right subtrees is at most 1.
- **Why rebalance?** They do this in order to maintain a height balance that allow for best-case scenarios.
- **Time Complexity (all operations):** O(log(n))

#### Rotation Cases
| Case | Imbalance | Fix |
|------|-----------|-----|
| LL   |     Left subtree of left child is heavier      |  Right rotation   |
| RR   |     Right subtree of right child is heavier      |  Left rotation   |
| LR   |     Right subtree of left child is heavier      |  Left rotation on child, then right rotation   |
| RL   |     Left subtree of right child is heavier      |  Right rotation on child, then left rotation   |


