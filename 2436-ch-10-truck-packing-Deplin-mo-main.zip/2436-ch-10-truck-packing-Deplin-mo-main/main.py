class Box:
    def __init__(self, label: str, length: float, width: float, height: float):
        self.label = label
        self.length = length
        self.width = width
        self.height = height

    def volume(self) -> float:
        """Calculate the volume of the box."""
        return self.length * self.width * self.height


def pack_truck(boxes: list, truck_volume: float) -> list:
    """Pack the truck using a greedy strategy based on box volumes."""
    
    # 1. Sort boxes in descending order of volume
    boxes_sorted = sorted(boxes, key=lambda box: box.volume(), reverse=True)

    packed_boxes = []
    used_volume = 0

    # 3. Iterate through sorted boxes
    for box in boxes_sorted:
        box_vol = box.volume()
        
        # 3a. If the box fits, add it
        if used_volume + box_vol <= truck_volume:
            packed_boxes.append(box)
            used_volume += box_vol

    return packed_boxes


if __name__ == "__main__":
    print("Welcome to the Truck Cargo Calculator")
    print("This program helps you calculate how to pack your cargo efficiently using a greedy algorithm.\n")

    # 1. Prompt user for truck dimensions
    length = float(input("Enter truck length: "))
    width = float(input("Enter truck width: "))
    height = float(input("Enter truck height: "))

    # 2. Calculate truck volume
    truck_volume = length * width * height
    print(f"Truck volume: {truck_volume:.2f}\n")

    boxes = []

    # Input boxes
    while True:
        label = input("Enter box label (or 'done' to finish): ")
        if label.lower() == "done":
            break

        length = float(input("Enter box length: "))
        width = float(input("Enter box width: "))
        height = float(input("Enter box height: "))

        box = Box(label, length, width, height)
        boxes.append(box)
        print()

    # Pack the truck
    packed_boxes = pack_truck(boxes, truck_volume)

    # Display results
    total_used = sum(box.volume() for box in packed_boxes)

    print("\nPacked Boxes:")
    for box in packed_boxes:
        print(f"{box.label} (Volume: {box.volume():.2f})")

    print(f"\nTotal volume used: {total_used:.2f}")
    print(f"Remaining volume: {truck_volume - total_used:.2f}")

    print("\nThank you for using the Truck Cargo Calculator.")