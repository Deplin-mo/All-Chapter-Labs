Student Information
Name: [Devon Hajdik]
Date: [5/7/2026]
Algorithm Analysis: Greedy Truck Packing Algorithm

Algorithm Understanding
What type of problem is this algorithm solving?
[This algorithm is usually used to make quick, somewhat, but not always, optimal decisions when trying to load a set of items into the least amount of containers.]

Is this greedy algorithm guaranteed to produce the optimal solution? Why or why not?
[No it is not because this algorithm does not take future possibilities into account, so the result may not always be the best.]

What is the greedy choice made in this algorithm?
[To try to fit as many boxes as possible within the fewest amount of loading trucks.]

Implementation Questions
Why do we sort the boxes in descending order of volume before packing?
[To make sure that the largest boxes get loaded first so then we can determine how many smaller boxes can fit.]

What would happen if we sorted the boxes in ascending order instead?
[If starting in ascending order, the trucks would likely be loaded with mostly smaller boxes, with little no room for the larger boxes.]

Why do we keep track of used_volume?
[To make sure that there are no duplicate boxes.]

Extension: Dimension Constraints
Why is checking only volume not sufficient for real-world packing?
[Because you might also need to take weight into account. You would need to check how much weight can be loaded into a truck.]

Give an example where a box fits by volume but not by dimensions.
[If a truck has a 10x10x10 space, and a box has the dimensions 25x2x2, the box may have enough volume to fit, but it's too lengthy to fit into the truck.]

How would you modify the algorithm to check dimension constraints before packing a box?
[I would have set dimension for the load size as well as the boxes, then compare the dimensions of the two and determine whether or not the box will fit.]

Reflection Questions
What is a limitation of this greedy approach? Provide a scenario where it fails to find the optimal solution.
[Because this algorithm initally only checks for volume, then results may not always be the most optimal, so you would have to add additional parameters to get betters 
solutions for more in-depth problems.]

How is this problem related to the Knapsack Problem?
[While the items being put into the knapsack have the volume to fit, they might or might not have the right dimensions to be able to fit into the sack in the first place.]

What type of algorithm would guarantee an optimal solution for this problem? What is the tradeoff?
[You would likely need to resort to Dynamic Programming in order to explore all the possible combinations. The downsides are that it runs much slower than a simple 
Greedy Truck Packing algorithm.]

If the truck had weight limits in addition to volume, how would the algorithm need to change?
[You would need to consider all possible weight combinations along with volume combinations.]

Why are greedy algorithms often preferred despite not always being optimal?
[Because they are quick and provide a good enough solution for a local problem.]
