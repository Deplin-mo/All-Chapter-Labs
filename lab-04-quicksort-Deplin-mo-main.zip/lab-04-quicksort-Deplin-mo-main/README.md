[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=22772162&assignment_repo_type=AssignmentRepo)
# Lab 04: Quicksort

## Student Information
- **Name:** [Devon Hajdik]
- **Date:** [5/7/2026]

## Quicksort Concepts

### Divide and Conquer
Quicksort splits a list into subproblems and solves each of those subproblems.

### The Three Steps
1. **Choose pivot:** The point at which the problem is divided.
2. **Partition:** Based on the pivot the list is sorted into one half with values less than the pivot and one with values greater than the pivot.
3. **Recurse and combine:** Each of those subproblems are worked out and then combined back into one solution.

## Tracing Quicksort

### Trace: quicksort([3, 5, 2, 1, 4])
Pivot = 3
Less than = [2, 1]
  Pivot = [2]
  Less than = [1]
  Greater than = []
Greater than = [5, 4]
  Pivot = [5]
  Less than = [4]
  Greater than = []
Combine: [1, 2, 3, 4, 5]

## Complexity Analysis

| Case | Time Complexity | Why? |
|------|----------------|------|
| Best | O(n log n) | The pivot splits the list evenly each time, creating log n levels of recursion, and each level processes n elements. |
| Average | O(n log n) | On average, partitions are reasonably balanced, so performance is close to the best case. |
| Worst | O(n²) | The pivot is always the smallest or largest element, creating highly unbalanced splits (one side has n−1 elements). |

## Reflection Questions

1. What happens if the array is already sorted and you always pick the first element as pivot?
   That would result in the worst case scenario, since the pivot will always be the smallest value, it will have
   to sort a list over and over again until the last values.

3. How could you improve pivot selection to avoid worst-case performance?
   Select a pivot that is roughly the median among the list of values.

5. How does quicksort compare to other sorting algorithms you know (e.g., bubble sort, merge sort)?
   Quicksort runs at an average of O(n log n). It is usually faster and uses less memory compared to others.

7. Why do we use `array[1:]` instead of `array` when building the less and greater lists?
  Because the first element of the array is the pivot, and you don't want to include it when partitioning.
