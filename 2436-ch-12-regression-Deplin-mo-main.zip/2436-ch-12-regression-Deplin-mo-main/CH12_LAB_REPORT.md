Student Information
Name: [Devon Hajdik] Date: [5/8/2026] Algorithm Analysis: K-Nearest Neighbors (KNN) Regression for Bakery Loaf Prediction

Algorithm Understanding
What type of problem is this algorithm solving? [Regression is used to predict values.]

How does KNN regression differ from KNN classification? [Regression is used to predict a continuous number, and takes an average of the values. Classification
looks through a list of values, and points out the most frequently occurring value.]

What does the "K" in KNN represent, and why did we choose k=4 for this problem? [The K represents the number of nearest points used to predict the result.
We used K=4 because we were using the 4 nearest neighbors.]

In your own words, explain how the model produces a prediction for a new day. [The model would go back and search through for days with the most similar forecast. It then 
measures how recent those past days were in relation to the new day. After finding the the nearest days, the model takes their loaf sales and averages them, which becomes 
the new day.]

Implementation Questions
Why do we separate the DataFrame into features (X) and target (y) before training? [It works like a graph. The X features are the inputs used to predict the Y targets.]

Why must the input to model.predict() be a 2D array (e.g., [[4, 1, 0]]) instead of a 1D array ([4, 1, 0])? [Because 2D arrays allow for X and Y coordinates, unlike 1D arrays.]

What does .fit(X, y) actually do for a KNN model? (Hint: it's different from most other ML algorithms.) [Rather than actually learning from the data, .fit(X, y) simply stores 
the data without processing it in any other way. It is called a lazy learner because it delays the computations for predictions until the actual prediction time.]

Why do we use .values when extracting columns from the DataFrame? [We use .values because in converts the data into a compatible format.]

Extension: Choosing K
What would happen if we set k=1? What are the risks? [Using only 1 nearest neighbor can be too little information, and it could make the model too 
dependent on that single neighbor, without adapting to new info. If the closet neighbor is not an accurate neighbor, the results could be very wrong.]

What would happen if we set k=20 (the size of the entire dataset)? What does the model become? [Every prediction would become the global average. This means 
that the model will not be able to learn anything because it has already taken all of the data points.]

How would you decide what value of k is best for a given dataset? [The best k is the one that gives the lowest prediction error on data the model has not seen before.
What you can do is split the dataset into a training set, which stores data learned, and a validation set, which tests different K values. You can keep checking for the K value 
that has the lowest validation error. Or you could use a cross-validation, by spliting the data into folds where you train and test a certain amount of folds, and then average the errors.]

Extension: Distance and Feature Scaling
KNN uses distance to find "nearest" neighbors. Our features have very different ranges: weather is 1–5, but weekend_holiday and game_on are 0/1. Why could this be a problem? [Features with larger ranges dominate the distance calculation]

Give an example of two days where the weather feature would unfairly dominate the distance calculation. [If there are two days that have very sunny weather, that would make the distance calculations difficult 
because there are already many other sunny days throughout the year that could be used in the calculations, this could result in unfair domination.]

How would you modify the data preparation step to fix this? (Hint: look up "feature scaling" or "StandardScaler".) [You could apply a scalar to more general, usually dominating factors
like sunny weather. This could balance the weather data with other factors like holidays.]

Reflection Questions
What is a limitation of KNN regression? Provide a scenario where it would make a poor prediction. [KNN regression can really only you past data points to make prediction,
and they would have to be similar for an accurate prediction. An example could be a bakery and its sales. It would be difficult to make sales predictions based on weather 
when sales could still be very inconsistent between sunny or rainy days.]

Our dataset only has 20 days of data. How might the predictions change if we had 2,000 days of data instead? [There would be many more possible nearest data points for the model to use. The
increase to the pool of data could provide the model a more accurate prediction since it would be more accurate to trends.]

What other features (beyond weather, weekend/holiday, and game day) could the bakery collect to improve predictions? [They could use seasons, special occasions like birthdays or weddings, or even trends on social media.]

KNN is sometimes called a "lazy learning" algorithm because it does almost no work during training. What is the tradeoff at prediction time? [The problem with this model is that, because the model would have to compare the data
with every training point, predictions are much slower than they could be.]

The autograder expects a prediction of approximately 70.5 loaves for today's conditions. Manually look at the dataset and identify which 4 historical days you think the model is averaging. Do their loaf counts average to 70.5? [Yes it
does average to 70.5. Days 3, 14, 18, and 19 are probably the days the model uses.]

Why might a bakery prefer a slightly inaccurate ML prediction over a human guess for daily loaf counts? [Because they are more data-driven and show more consistency.]

If the bakery wanted to MINIMIZE waste (unsold loaves) rather than just predict accurately, how might you change the approach? [Probably lowball your predictions so the need to minimize waste is considered in the predictions.]
