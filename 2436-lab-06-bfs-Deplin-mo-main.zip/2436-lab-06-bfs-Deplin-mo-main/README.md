[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=22956628&assignment_repo_type=AssignmentRepo)
# Lab 06: 2436 Ch06

## Student Information
- **Name:** [Devon Hajdik]
- **Date:** [5/7/2026]

## Key Concepts
Breadth-First Search is used to find the shortest, unweighted path on a graph. It does this by going through each layer of nodes
until it reaches a node that no longer continues. 
## What I Learned
This algorithm is used best when finding a quickest route that has no weight. The route cannot backtrack.
## Challenges
Just trying to get the code to go through a graph properly, but it worked after I made some minor changes. 
## Reflection Questions
1. BFS uses a queue/FIFO because it needs to explore nodes in the order they are discovered, from one layer to the next.
2. BFS gives the shortest route simply based on the number of edges passed, but because the routes have no weight such as time,
   it may not always be the shortest path.
3. Use BFS when looking for the shortest path from layer to layer. Use DFS when looking through the entirity of every path.

---
*Complete this lab report after finishing the coding portion. Your final commit should include both working code and a completed lab report.*
