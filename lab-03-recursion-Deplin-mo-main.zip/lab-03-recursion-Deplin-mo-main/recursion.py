"""
Lab 03: Recursion
Implement recursive functions from Chapter 3.

Every recursive function has two cases:
1. Base case - when the function doesn't call itself
2. Recursive case - when the function calls itself
"""
from typing import List


def countdown(i: int) -> None:
    """
    Print countdown from i to 0.
    
    From Chapter 3 (page 45):
    Base case: i <= 0
    Recursive case: print i, then countdown(i-1)
    """
    # TODO: Implement countdown
    # 1. If i <= 0, print 0 and return
    # 2. Otherwise, print i
    # 3. Call countdown(i - 1)
    if i <= 0:
        print(0);
        return;
    else: 
        print(i);
    countdown(i-1);


def fact(x: int) -> int:
    if x <= 1:
        return 1
    return x * fact(x-1)

def recursive_sum(arr: list) -> int:
    if not arr:
        return 0
    return arr[0] + recursive_sum(arr[1:])


def recursive_count(arr: list) -> int:
    # Base case: empty list
    if not arr:
        return 0
    # Recursive case
    return 1 + recursive_count(arr[1:])

def recursive_max(arr: list) -> int:
    # Base case: single element
    if len(arr) == 1:
        return arr[0]
    rest_max = recursive_max(arr[1:])
    return arr[0] if arr[0] > rest_max else rest_max
