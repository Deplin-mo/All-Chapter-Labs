Lab Report — Dijkstra's Shortest Path

Student Information

Name: [Devon Hajdik]
Date: [5/7/2026]
Algorithm Analysis: Dijkstra's Algorithm

What type of graph does this program build? [Directed, weighted]
Why must all edge weights be non-negative for Dijkstra's to work? [Because there can be no negative distance values.]
Time Complexity (with simple array scan for min-node): O(V^2)
Time Complexity (with a min-heap/priority queue): O((V+E)log(V))
Core Data Structures

Structure	Variable Name	What It Stores
Adjacency dict	graph	
Cost table	costs	
Parent table	parents	
Visited list	processed	
Algorithm Trace

Given nodes A, B, C, D and edges A-B(1), A-C(4), B-C(2), B-D(6), C-D(3), trace Dijkstra's from A to D:

Iteration	Current Node	costs[A]	costs[B]	costs[C]	costs[D]	processed
Init	—					-          0          inf        inf          inf      {}
1			          A          0          1        4          inf       {A}         			
2						    B          0          1        3          7         {A, B}
3						    C          0          1        3          6        {A, B, C}
4						    D          0          1        3          6        {A, B, C, D}
Shortest path A to D: A -> B -> C -> D
Total cost: 6

Reflection Questions

Why does the algorithm initialize all node costs to infinity except the start node? 
  They are initially all infinte because we do not know any paths chosen, so they're essentially unknown.

Why do we store edges in both directions (graph[a][b] and graph[b][a])? What would break if we only stored one direction?
  Because these graphs are undirected. This could prevent certain paths that require backtracking to fail because they
  wouldn't be able to go back.

The find_lowest_cost_node() function scans all nodes linearly. How would using a priority queue (min-heap) improve performance, and why does it matter for large graphs?
  Using a priority queue still always returns the smallest-cost route, but does so at a significantly faster rate. Especially with larger graphs, using the lowest cost nodes 
  function would become very slow with its O(V^2) complexity.

If a negative edge weight were introduced (e.g., A-B with weight -3), explain how Dijkstra's algorithm could produce an incorrect result. What algorithm handles negative weights?
  Taking in negative values could affect the total cost of a path. And that could also affect the supposed cost of another path, therefore producing an inaccurate result.

How does the parents dictionary allow path reconstruction? Why do we reverse the path at the end?
  The parents dictionary stores the node or nodes used to reach a point at the lowest cost. Meaning the lowest-cost path can easily be reconstructed using the dictionary.

What happens when the source and destination are in disconnected components of the graph? How does the code detect this?
  This would cause some nodes to remain at an infinite cost because a destination would never be reached. If the code detects an infinite cost, it marks it as unreachable.
